#include <iostream> 
  
using namespace std;

int main() 
{ 
    int num; 
    int tempNum;
     
    num = 18; 

    tempNum = 2 * num;

    cout << "Num = " << num << ", tempNum = " << tempNum << endl; 

    return 0;
}
