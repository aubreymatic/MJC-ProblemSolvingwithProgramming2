 
#include <iostream>
#include "binarySearchTree.h"

using namespace std;

int main()
{
    cout << "See Programming Exercise 5." << endl;

    return 0;
}