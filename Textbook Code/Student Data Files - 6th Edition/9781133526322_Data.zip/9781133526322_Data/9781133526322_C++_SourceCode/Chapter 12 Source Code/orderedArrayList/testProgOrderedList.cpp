#include <iostream>
#include "orderedArrayListType.h"
 
using namespace std;

int main() 
{
    cout << "See Programming Exercise 11." << endl;            

	return 0;  
}
