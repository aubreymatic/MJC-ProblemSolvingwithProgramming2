  
#include <iostream>

using namespace std;

int main() 
{
    cout << "See Programming Exercise 14.";  
 
    return 0;					
}



