
#include <iostream>
#include "minimalSpanTreeType.h"

using namespace std;

int main()  
{
	cout << "See Programming Exercise 4." << endl;
 
	return 0;
}