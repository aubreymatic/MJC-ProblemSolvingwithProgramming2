//savingsAccount

#ifndef H_savingsAccount
#define H_savingsAccount

#include "bankaccount.h"

class savingsAccount :
  public bankAccount
{
public:
	savingsAccount(int acctNum, string name, double initialBalance);

	void withdraw(double amount);

	void printSummary();
  
	void printStatement();


protected:
  double m_InterestRate;

};
#endif // !H_savingsAccount