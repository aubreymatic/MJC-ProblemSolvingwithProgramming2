//serviceChargeChecking

#ifndef H_serviceChargeChecking
#define H_serviceChargeChecking

#include "checkingaccount.h"

class serviceChargeChecking :
  public checkingAccount
{
public:
	serviceChargeChecking(int acctNum, string name, double initialBalance);
  
  void writeCheck(double amount);

  void printSummary();
};
#endif // !H_serviceChargeChecking