#include "bankAccount.h"
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;


	bankAccount::bankAccount(int acctNum, string name, double initialBalance)
	{
		m_AcctNumber = acctNum;
		m_Name = name;
		m_Balance = initialBalance;
	}

	string bankAccount::get_Name()
	{
		return m_Name;
	}

	int bankAccount::get_AcctNumber()
	{
		return m_AcctNumber;
	}

	double bankAccount::get_Balance()
	{
		return m_Balance;
	}

	void bankAccount::deposit(double amount)
	{
		m_Balance += amount;
		cout << "$" << amount << " has been deposited to your account" << endl;
	}


