
#include "checkingAccount.h"

checkingAccount::checkingAccount(int acctNum, string name, double initialBalance)
	: bankAccount(acctNum, name, initialBalance)
{
}


void checkingAccount::withdraw(double amount)
{
	if (m_Balance - amount < 0)
	{
		cout << "Declined: Insufficient funds remain to withdraw that amount" << endl;
		return;
	}
	if (m_Balance - amount < m_MinimumBalance)
	{
		cout << "Declined: Minimum balance requirement prohibits this withdrawal" << endl;
		return;
	}
	m_Balance -= amount;
}

void checkingAccount::printStatement()
{
	printSummary();
	cout << endl << "A full implementation would also print details of a Checking Account Statement here." << endl << endl;
}