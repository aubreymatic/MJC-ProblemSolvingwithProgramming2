//certificateOfDeposit

#ifndef H_certificateOfDeposit
#define H_certificateOfDeposit

#include "bankaccount.h"

class certificateOfDeposit : public bankAccount
{
public:
	certificateOfDeposit(int acctNum, string name, double initialBalance, int matMon);

  void withdraw(double amount);

  void printSummary();

  void printStatement();

private:
  double m_InterestRate;
  int m_MaturityMonths;
  int m_CurrentMonth;
};
#endif // !H_certificateOfDeposit