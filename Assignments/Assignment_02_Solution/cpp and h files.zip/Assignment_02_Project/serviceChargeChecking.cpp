
#include "serviceChargeChecking.h"

const int MAX_CHECKS = 5;
const double SVC_CHARGE = 10.0l;

serviceChargeChecking::serviceChargeChecking(int acctNum, string name, double initialBalance)
	: checkingAccount(acctNum, name, initialBalance)
{
	m_InterestRate = 0; // No interest
	m_ChecksRemaining = MAX_CHECKS; // Limit of 5 checks
	m_MinimumBalance = 0; // No minimum balance
}

void serviceChargeChecking::writeCheck(double amount)
{
	if (m_ChecksRemaining == 0)
	{
		cout << "Declined: No more checks remaining this month" << endl;
		return;
	}

	if (m_Balance - amount < 0)
	{
		cout << "Declined: Insufficient funds remain to withdraw that amount" << endl;
		return;
	}

	m_ChecksRemaining--;
	m_Balance -= amount; // Assume check is cashed immediately...

}

void serviceChargeChecking::printSummary()
{
	// Use the root base class to print common info
	bankAccount::printSummary();
	cout << setw(25) << "Checks remaining:  " << m_ChecksRemaining << endl;
	cout << setw(25) << "Monthly service fee: $" << SVC_CHARGE << endl;
	cout << setw(25) << "No interest  " << endl;
	cout << setw(25) << "No Minimum Balance  " << endl;
	cout << setw(60) << setfill('-') << "" << setfill(' ') << endl;
}