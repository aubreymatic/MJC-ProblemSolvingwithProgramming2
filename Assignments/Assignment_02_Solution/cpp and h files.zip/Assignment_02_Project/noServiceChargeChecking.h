//noServiceChargeChecking

#ifndef H_noServiceChargeChecking
#define H_noServiceChargeChecking

#include "checkingaccount.h"

class noServiceChargeChecking :
  public checkingAccount
{
public:
	noServiceChargeChecking(int acctNum, string name, double initialBalance);

  void writeCheck(double amount);

  void printSummary();

};
#endif // !H_noServiceChargeChecking