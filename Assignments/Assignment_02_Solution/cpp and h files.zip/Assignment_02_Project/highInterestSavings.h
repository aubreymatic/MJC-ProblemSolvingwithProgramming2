//highInterestSavings

#ifndef H_highInterestSavings
#define H_highInterestSavings

#include "savingsaccount.h"

class highInterestSavings :
  public savingsAccount
{
public:
	highInterestSavings(int acctNum, string name, double initialBalance);

  void withdraw(double amount);

  void printSummary();


protected:
  double m_MinimumBalance;

};
#endif // !H_highInterestSavings