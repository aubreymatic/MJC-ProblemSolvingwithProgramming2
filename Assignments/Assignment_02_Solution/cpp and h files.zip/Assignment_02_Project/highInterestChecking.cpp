
#include "highInterestChecking.h"

highInterestChecking::highInterestChecking(int acctNum, string name, double initialBalance)
	: noServiceChargeChecking(acctNum, name, initialBalance)
{
	// The only difference between the base class noServiceChargeChecking 
	// is the values of interest and minimum balance. 
	// So no additional functionality needed for this one.

	m_InterestRate = 5.0; // Higher interest rate
	m_ChecksRemaining = -1; // -1 indicates no limit
	m_MinimumBalance = 1000; // Minimum balance
}