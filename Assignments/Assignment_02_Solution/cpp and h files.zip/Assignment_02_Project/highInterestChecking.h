//highInterestChecking

#ifndef H_highInterestChecking
#define H_highInterestChecking

#include "noservicechargechecking.h"

class highInterestChecking :
  public noServiceChargeChecking
{
public:
	highInterestChecking(int acctNum, string name, double initialBalance);
};
#endif // !H_highInterestChecking