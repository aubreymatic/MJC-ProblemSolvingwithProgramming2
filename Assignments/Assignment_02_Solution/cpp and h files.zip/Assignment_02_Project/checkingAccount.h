//checkingAccount

#ifndef H_checkingAccount
#define H_checkingAccount

#include "bankaccount.h"

class checkingAccount :
	public bankAccount
{
public:
	checkingAccount(int acctNum, string name, double initialBalance);

	virtual void writeCheck(double amount) = 0;

	void withdraw(double amount);

	void printStatement();

protected:
	double m_InterestRate;
	int m_ChecksRemaining;
	double m_MinimumBalance;
};
#endif // !H_checkingAccount